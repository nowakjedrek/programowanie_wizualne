﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using CsvHelper;
using CsvHelper.Configuration.Attributes;
using System.Globalization;
using Microsoft.Win32;

namespace lab8
{
    /// <summary>
    /// Logika interakcji dla klasy MainWindow.xaml
    /// </summary>
    /// 

    public class Lotnisko
    {
        [Index(0)]
        public string Miasto { get; set; }
        [Index(1)]
        public string Wojewodztwo { get; set; }
        [Index(2)]
        public string Icao { get; set; }
        [Index(3)]
        public string Iata { get; set; }
        [Index(4)]
        public string Nazwa { get; set; }
        [Index(5)]
        public string Pasazerowie { get; set; }
        [Index(6)]
        public string Zmiana { get; set; }

    }
   
    public partial class MainWindow : Window
    {
        List<Lotnisko> lista_lotnisk = new List<Lotnisko>();
        IEnumerable<Lotnisko> lotniska;
        public List<string> wybrane = new List<string>();
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Wczytaj_Click(object sender, RoutedEventArgs e)
        {
            FileDialog fileDialog = new OpenFileDialog();
            fileDialog.ShowDialog();
            string CSV_InputPath = fileDialog.FileName;
            List_view.Items.Clear();


            using (var reader = new StreamReader(CSV_InputPath, Encoding.UTF8))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                lotniska = csv.GetRecords<Lotnisko>();
                lista_lotnisk = lotniska.ToList();
            }
            foreach (var item in lista_lotnisk)
            {
                List_view.Items.Add(item);
            }
        }

        private void Szczegoly_Click(object sender, RoutedEventArgs e)
        {
            if(List_view.SelectedItems.Count != 0)
            {
                if (ICAO_checkbox.IsChecked == true)
                {
                    wybrane.Add(ICAO_checkbox.Name.ToString());
                    
                }
                if (IATA_checkbox.IsChecked == true)
                {
                    wybrane.Add(IATA_checkbox.Name.ToString());
                }
                if (Miasto_checkbox.IsChecked == true)
                {
                    wybrane.Add(Miasto_checkbox.Name.ToString());
                }
                if (Pasazerowie_checkbox.IsChecked == true)
                {
                    wybrane.Add(Pasazerowie_checkbox.Name.ToString());
                }
                if (Wojewodztwo_checkbox.IsChecked == true)
                {
                    wybrane.Add(Wojewodztwo_checkbox.Name.ToString());
                }
                if (Zmiana_checkbox.IsChecked == true)
                {
                    wybrane.Add(Zmiana_checkbox.Name.ToString());
                }
                Window1 subwindow = new Window1(this);
                subwindow.Show();
                
            }
            else
            {
                MessageBox.Show("Nie wybrano lotniska! Wybierz lotnisko");
            }
        }


        
    }
}
